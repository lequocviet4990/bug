﻿using System;

namespace DIDEMOEx
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Horn horn = new Horn(9);

            var car = new Car(horn); // horn inject vào car
            car.Beep(); // Beep - beep - beep ...    // (kểu to lắm) BEEP BEEP BEEP ...

            Console.WriteLine("Hello World!");
        }

        public class Horn
        {
            private int level; // thêm độ lớn còi xe

            public Horn(int level) => this.level = level; // thêm khởi tạo level

            public void Beep() => Console.WriteLine("Beep - beep - beep ...");
        }

        public class Car
        {
            // horn là một Dependecy của Car
            private Horn horn;

            // dependency Horn được đưa vào Car qua hàm khởi tạo
            public Car(Horn horn) => this.horn = horn;

            public void Beep()
            {
                // Sử dụng Dependecy đã được Inject
                horn.Beep();
            }
        }
    }
}