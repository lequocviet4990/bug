﻿using Microsoft.Extensions.DependencyInjection;
using System;

namespace DemoServiceCollection
{
    class Program
    {
        static void Main(string[] args)
        {
            IServiceCollection services = new ServiceCollection();
            services.AddTransient<FooService>();
            var serviceProvider = services.BuildServiceProvider();
            var fooService = serviceProvider.GetService<FooService>();
            fooService.DoIt();
        }

        public class FooService
        {
            public void DoIt()
            {
                Console.WriteLine("This is Microsoft DI!");
            }
        }

    }
}
