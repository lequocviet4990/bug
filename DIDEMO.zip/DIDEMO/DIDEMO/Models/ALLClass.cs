﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DIDEMO.Models
{
    public interface IListProductName
    {
        // Trả về danh sách các tên
        IEnumerable<string> GetNames();
    }

    public class LaptopName : IListProductName
    {
        public LaptopName() => System.Console.WriteLine("LaptopName Created");
        // Mảng tên sản phẩm
        string[] laptops = new string[]  {
      "Apple MacBook Pro 13 inch", "HP Spectre X360", "Samsung Chromebook Pro"};

        public IEnumerable<string> GetNames()
        {
            return laptops;
        }
    }

    public class PhoneName : IListProductName
    {
        public PhoneName() => System.Console.WriteLine("PhoneName created");
        // Mảng tên các điện thoại
        private List<string> phone_names = new List<string> {
        "Iphone 7", "Samsung Galaxy", "Nokia 123"
    };
        public IEnumerable<string> GetNames()
        {
            return phone_names;
        }
    }


}
