﻿namespace AutofacDemo
{
    public interface ISampleService2
    {
        string Main();
    }
}