﻿namespace AutofacDemo
{
    public interface ISampleService
    {
        void Main();
    }
}