﻿using Autofac;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AutofacDemo
{
    public class AutofacModule:Module
    {

      /*  Module là một class nhỏ dùng để tập hợp các thành phần có liên quan với nhau, 
       *  để đơn giản cấu hình và triển khai.Lợi ích của việc đăng ký theo Module là bạn 
       *  sẽ dễ quản lý các thư viện phụ thuộc, và quan trọng hơn bạn tránh lặp lại code 
       *  đăng ký Dependency khi sử dụng nhiều web host trỏ vào các service.Đăng ký Module
            Ở Project Services, bạn khai báo:

        */
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<MessageRepository>().As<IMessageRepository>();

            string setting = "";
            builder.Register(c => new SampleService(c.Resolve<IServiceProvider>(), setting)).As<ISampleService>().InstancePerLifetimeScope();


        }
    }
}
