﻿namespace AutofacDemo
{
    public interface IMessageRepository
    {
        /// <summary>
        /// return message
        /// </summary>
        /// <returns></returns>
        string GetMessage();
    }
    public class MessageRepository : IMessageRepository
    {
        public string GetMessage()
        {
            return "Message Repository";
        }
    }
}