﻿using System;

namespace AutofacDemo
{
    public class SampleService2:ISampleService2
    {
        private IServiceProvider serviceProvider;
        private string setting;

        public SampleService2(IServiceProvider serviceProvider, string setting)
        {
            this.serviceProvider = serviceProvider;
            this.setting = setting;
        }

        public string Main()
        {
           return "ToDo";
        }
    }
}