﻿using Microsoft.Extensions.DependencyInjection;
using System;

namespace AutofacDemo
{
    public class SampleService:ISampleService
    {
        private IServiceProvider serviceProvider;
        private ISampleService2 sampleService2;
        private string setting;

        public SampleService(IServiceProvider serviceProvider, string setting)
        {
            this.serviceProvider = serviceProvider;
            this.setting = setting;
            sampleService2 =  serviceProvider.GetRequiredService<ISampleService2>();
        }

        public void Main()
        {
            var stringtest = "ToDo";
            var atest = sampleService2.Main();
        }
    }
}